import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import {Employee} from './employee';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
  id:number=0;
  constructor(private route: ActivatedRoute) {
    console.log("hello");
    this.route.params.subscribe(params=>{this.id=+params['id'];});
    console.log("id value is :"+this.id);
   }
   
  emp: Employee[]=[

    new Employee(11,"chandra","CSE",21),
    new Employee(12,"Rishika","ECE",22),
    new Employee(13,"Teja","CSE",23),
    new Employee(14,"Suresh","ECE",24)
  ]
   flag:number=0;
   l:number=0;
   name:string;
   dept:string;
   age:number;
  ngOnInit(): void {
    console.log("hello");
    for(let index=0;index<this.emp.length;index++){
      console.log("data:"+this.emp[index].id+" "+this.id);
      if(this.id==this.emp[index].id){
        this.flag=1;
        this.l=index
        console.log("data:"+this.id);
      }
    }
      this.id=this.emp[this.l].id;
      this.name=this.emp[this.l].name;
      this.dept=this.emp[this.l].dept;
      this.age=this.emp[this.l].age;

  }

}
