import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Student } from './student';
@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit {
  id:number=0;
  constructor(private route: ActivatedRoute) {
    console.log("hello");
    this.route.params.subscribe(params=>{this.id=+params['id'];});
    console.log("id value is :"+this.id);
   }
   
  emp: Student[]=[

    new Student(11,"chandra","CSE"),
    new Student(12,"Rishika","ECE"),
    new Student(13,"Teja","CSE"),
    new Student(14,"Suresh","ECE")
  ]
   flag:number=0;
   l:number=0;
   name:string;
   dept:string;
  ngOnInit(): void {
    console.log("hello");
    for(let index=0;index<this.emp.length;index++){
      console.log("data:"+this.emp[index].id+" "+this.id);
      if(this.id==this.emp[index].id){
        this.flag=1;
        this.l=index
        console.log("data:"+this.id);
      }
    }
      this.id=this.emp[this.l].id;
      this.name=this.emp[this.l].name;
      this.dept=this.emp[this.l].dept;

  }

}
